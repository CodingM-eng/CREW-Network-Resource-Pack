CREW Network 64x — Java 1.21.11
Ayrıntılı Türkçe kurulum ve kapsam notları, proje klasöründeki README.md dosyasındadır.
Bu pakette CubeCraft dosyaları kullanılmamıştır.
